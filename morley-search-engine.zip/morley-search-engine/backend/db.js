/*!
 * © 2026 Morley Moses Apooch. All Rights Reserved.
 * Treaty No. 3760080802 | Manager/CEO | Yorkton, SK, Canada
 * apoochmorley@protonmail.com | moapooch121@gmail.com | +1-639-766-1738
 * Licensed under the Morley Apooch Proprietary License. See LICENSE.md.
 * ----------------------------------------------------------------------
 * MorleyDB — a lightweight, dependency-free, collection-based database
 * engine. Persists to disk as JSON "shards" so it behaves like a document
 * database (Mongo/Firestore-style) while requiring zero external services.
 *
 * PRODUCTION NOTE: this engine is a fully functional reference
 * implementation suitable for small/medium workloads and local or
 * single-VM deployment. To scale to a managed cloud database, swap the
 * storage adapter below for Postgres, MongoDB Atlas, DynamoDB, or
 * Firestore — the Collection API (insert/find/update/remove/createIndex)
 * is intentionally modeled so that swap does not require touching the
 * search engine or the API layer.
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { COPYRIGHT_NOTICE } = require("./copyright");

const DATA_DIR = path.join(__dirname, "..", "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function newId() {
  return crypto.randomBytes(12).toString("hex");
}

class Collection {
  constructor(name, schema = {}) {
    this.name = name;
    this.schema = schema; // { field: { type, required } }
    this.file = path.join(DATA_DIR, `${name}.json`);
    this.indexes = new Map(); // field -> Map(value -> Set(ids))
    this._load();
  }

  _load() {
    if (fs.existsSync(this.file)) {
      this.records = JSON.parse(fs.readFileSync(this.file, "utf-8"));
    } else {
      this.records = {};
      this._persist();
    }
  }

  _persist() {
    fs.writeFileSync(this.file, JSON.stringify(this.records, null, 2));
  }

  _validate(doc) {
    for (const [field, rules] of Object.entries(this.schema)) {
      if (rules.required && !(field in doc)) {
        throw new Error(`Validation error: "${field}" is required in collection "${this.name}"`);
      }
      if (field in doc && rules.type && typeof doc[field] !== rules.type) {
        throw new Error(
          `Validation error: "${field}" must be of type ${rules.type} in collection "${this.name}"`
        );
      }
    }
  }

  createIndex(field) {
    const map = new Map();
    for (const [id, doc] of Object.entries(this.records)) {
      const key = doc[field];
      if (key === undefined) continue;
      if (!map.has(key)) map.set(key, new Set());
      map.get(key).add(id);
    }
    this.indexes.set(field, map);
    return this;
  }

  _indexOnInsert(id, doc) {
    for (const [field, map] of this.indexes.entries()) {
      const key = doc[field];
      if (key === undefined) continue;
      if (!map.has(key)) map.set(key, new Set());
      map.get(key).add(id);
    }
  }

  insert(doc) {
    this._validate(doc);
    const id = doc.id || newId();
    const record = { ...doc, id, _createdAt: new Date().toISOString() };
    this.records[id] = record;
    this._indexOnInsert(id, record);
    this._persist();
    return record;
  }

  findById(id) {
    return this.records[id] || null;
  }

  find(predicate = () => true) {
    return Object.values(this.records).filter(predicate);
  }

  findByIndex(field, value) {
    const map = this.indexes.get(field);
    if (!map) return this.find((d) => d[field] === value);
    const ids = map.get(value) || new Set();
    return [...ids].map((id) => this.records[id]);
  }

  update(id, patch) {
    if (!this.records[id]) return null;
    this.records[id] = { ...this.records[id], ...patch, _updatedAt: new Date().toISOString() };
    this._persist();
    return this.records[id];
  }

  remove(id) {
    if (!this.records[id]) return false;
    delete this.records[id];
    for (const map of this.indexes.values()) {
      for (const ids of map.values()) ids.delete(id);
    }
    this._persist();
    return true;
  }

  all() {
    return Object.values(this.records);
  }

  count() {
    return Object.keys(this.records).length;
  }
}

class MorleyDB {
  constructor() {
    this.collections = new Map();
    this.meta = { license: COPYRIGHT_NOTICE.statement, owner: COPYRIGHT_NOTICE.owner };
  }

  collection(name, schema) {
    if (!this.collections.has(name)) {
      this.collections.set(name, new Collection(name, schema));
    }
    return this.collections.get(name);
  }
}

module.exports = { MorleyDB, Collection };
