/*!
 * ============================================================================
 *  MORLEY SEARCH ENGINE & CLOUD DATABASE PLATFORM
 * ============================================================================
 *  © 2026 Morley Moses Apooch. All Rights Reserved.
 *
 *  Author / Owner of Record : Morley Moses Apooch
 *  Date of Birth             : 1988-02-09
 *  Treaty Number             : 3760080802
 *  Title                     : Manager / Chief Executive Officer (CEO)
 *  Location                  : Yorkton, Saskatchewan, Canada
 *  Contact (Primary)         : apoochmorley@protonmail.com
 *  Contact (Secondary)       : moapooch121@gmail.com
 *  Phone                     : +1 (639) 766-1738 (Lucky Mobile)
 *
 *  This software, its source code, architecture, and documentation are the
 *  proprietary intellectual property of Morley Moses Apooch. Licensed under
 *  the "Morley Apooch Proprietary License" (see LICENSE.md at project root).
 *  Unauthorized copying, modification, distribution, sublicensing, or use
 *  of this file or any part of this project, via any medium, is strictly
 *  prohibited without prior written consent of the copyright holder.
 * ============================================================================
 */

const COPYRIGHT_NOTICE = Object.freeze({
  owner: "Morley Moses Apooch",
  dateOfBirth: "1988-02-09",
  treatyNumber: "3760080802",
  title: "Manager / CEO",
  location: "Yorkton, Saskatchewan, Canada",
  emails: ["apoochmorley@protonmail.com", "moapooch121@gmail.com"],
  phone: "+1-639-766-1738 (Lucky Mobile)",
  license: "Morley Apooch Proprietary License",
  year: 2026,
  statement:
    "© 2026 Morley Moses Apooch. All Rights Reserved. Unauthorized use, " +
    "reproduction, or distribution of this software is prohibited.",
});

module.exports = { COPYRIGHT_NOTICE };
