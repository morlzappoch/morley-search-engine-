/*!
 * © 2026 Morley Moses Apooch. All Rights Reserved.
 * Author of Record: Morley Moses Apooch (b. 1988-02-09)
 * Treaty No. 3760080802 | Manager/CEO | Yorkton, Saskatchewan, Canada
 * apoochmorley@protonmail.com | moapooch121@gmail.com | +1-639-766-1738
 * Licensed under the Morley Apooch Proprietary License. See LICENSE.md.
 * Unauthorized copying, distribution, or use is strictly prohibited.
 * ----------------------------------------------------------------------
 * Zero-dependency REST API server (built on Node's core "http" module —
 * no npm install required). Exposes the MorleyDB database and the
 * MorleySearch engine, and serves the front-end SPA.
 *
 * Run:   node backend/server.js
 * Open:  http://localhost:8080
 *
 * Cross-platform: runs identically on Windows, macOS, and Linux anywhere
 * Node.js 18+ is installed. Deploys as-is to any Node host (Render,
 * Railway, Fly.io, Azure App Service, AWS Elastic Beanstalk/EC2, a
 * Raspberry Pi, etc.) with no build step.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");
const { MorleyDB } = require("./db");
const { SearchEngine } = require("./search-engine");
const { COPYRIGHT_NOTICE } = require("./copyright");

const PORT = process.env.PORT || 8080;
const FRONTEND_DIR = path.join(__dirname, "..", "frontend");

const db = new MorleyDB();
const documents = db.collection("documents", {
  title: { type: "string", required: true },
  content: { type: "string", required: true },
});
documents.createIndex("url");

const engine = new SearchEngine();
// Rebuild the search index from whatever is already persisted on disk.
for (const doc of documents.all()) {
  engine.indexDocument(doc.id, doc);
}

function sendJSON(res, status, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "X-Copyright": COPYRIGHT_NOTICE.statement,
    "Access-Control-Allow-Origin": "*",
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

const MIME = {
  ".html": "text/html",
  ".js": "text/javascript",
  ".css": "text/css",
  ".json": "application/json",
};

function serveStatic(req, res, pathname) {
  const filePath = path.join(
    FRONTEND_DIR,
    pathname === "/" ? "index.html" : pathname
  );
  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const { pathname, query } = parsed;

  try {
    // --- API routes ---
    if (pathname === "/api/health") {
      return sendJSON(res, 200, { status: "ok", ...db.meta, ...engine.stats() });
    }

    if (pathname === "/api/documents" && req.method === "GET") {
      return sendJSON(res, 200, documents.all());
    }

    if (pathname === "/api/documents" && req.method === "POST") {
      const body = await readBody(req);
      const doc = documents.insert({
        title: body.title,
        content: body.content,
        url: body.url || "",
        tags: body.tags || [],
      });
      engine.indexDocument(doc.id, doc);
      return sendJSON(res, 201, doc);
    }

    if (pathname.startsWith("/api/documents/") && req.method === "DELETE") {
      const id = pathname.split("/").pop();
      const ok = documents.remove(id);
      if (ok) engine.removeDocument(id);
      return sendJSON(res, ok ? 200 : 404, { deleted: ok, id });
    }

    if (pathname === "/api/search" && req.method === "GET") {
      const q = query.q || "";
      const limit = Number(query.limit) || 10;
      const results = engine.search(q, { limit });
      return sendJSON(res, 200, { query: q, count: results.length, results });
    }

    if (pathname === "/api/suggest" && req.method === "GET") {
      const prefix = query.q || "";
      return sendJSON(res, 200, { suggestions: engine.suggest(prefix) });
    }

    // --- static frontend ---
    if (req.method === "GET") {
      return serveStatic(req, res, pathname);
    }

    return sendJSON(res, 405, { error: "Method not allowed" });
  } catch (err) {
    return sendJSON(res, 500, { error: err.message });
  }
});

server.listen(PORT, () => {
  console.log(`\n${COPYRIGHT_NOTICE.statement}`);
  console.log(`Owner of record: ${COPYRIGHT_NOTICE.owner} — ${COPYRIGHT_NOTICE.title}`);
  console.log(`Morley Search Engine running at http://localhost:${PORT}\n`);
});

module.exports = { server, db, engine };
