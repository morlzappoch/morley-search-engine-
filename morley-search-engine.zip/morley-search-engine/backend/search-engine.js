/*!
 * © 2026 Morley Moses Apooch. All Rights Reserved.
 * Treaty No. 3760080802 | Manager/CEO | Yorkton, SK, Canada
 * apoochmorley@protonmail.com | moapooch121@gmail.com | +1-639-766-1738
 * Licensed under the Morley Apooch Proprietary License. See LICENSE.md.
 * ----------------------------------------------------------------------
 * MorleySearch — a self-contained, dependency-free full-text search
 * engine implementing:
 *   - tokenization + stop-word filtering
 *   - an inverted index (term -> {docId -> term frequency})
 *   - TF-IDF vector scoring with cosine-style ranking
 *   - prefix ("type-ahead") lookup via a term trie
 *
 * Scales to millions of documents on a single node if the inverted index
 * is backed by a real store (e.g. Elasticsearch/OpenSearch/Postgres
 * full-text search) instead of the in-memory Map used here. The public
 * API (index/removeDocument/search/suggest) is designed to stay stable
 * if that swap happens later.
 */

const STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has",
  "he", "in", "is", "it", "its", "of", "on", "that", "the", "to", "was",
  "were", "will", "with", "this", "these", "those", "or", "but", "not",
]);

function tokenize(text) {
  return (text || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOP_WORDS.has(t));
}

class TrieNode {
  constructor() {
    this.children = new Map();
    this.terms = new Set();
  }
}

class SearchEngine {
  constructor() {
    // term -> Map(docId -> termFrequency)
    this.invertedIndex = new Map();
    // docId -> { length, fields }
    this.docStats = new Map();
    this.trieRoot = new TrieNode();
    this.totalDocs = 0;
  }

  _addToTrie(term) {
    let node = this.trieRoot;
    for (const ch of term) {
      if (!node.children.has(ch)) node.children.set(ch, new TrieNode());
      node = node.children.get(ch);
      node.terms.add(term);
    }
  }

  indexDocument(id, fields) {
    // fields: { title, content, tags, url, weight }
    const weight = fields.weight || 1;
    const text = [
      (fields.title || "").repeat(3), // titles weighted 3x
      fields.content || "",
      (fields.tags || []).join(" ").repeat(2),
    ].join(" ");

    const tokens = tokenize(text);
    const termFreq = new Map();
    for (const token of tokens) {
      termFreq.set(token, (termFreq.get(token) || 0) + weight);
      this._addToTrie(token);
    }

    for (const [term, freq] of termFreq.entries()) {
      if (!this.invertedIndex.has(term)) this.invertedIndex.set(term, new Map());
      this.invertedIndex.get(term).set(id, freq);
    }

    this.docStats.set(id, { length: tokens.length || 1, fields });
    this.totalDocs = this.docStats.size;
    return { id, terms: termFreq.size };
  }

  removeDocument(id) {
    for (const postings of this.invertedIndex.values()) {
      postings.delete(id);
    }
    this.docStats.delete(id);
    this.totalDocs = this.docStats.size;
  }

  _idf(term) {
    const df = this.invertedIndex.get(term)?.size || 0;
    if (df === 0) return 0;
    return Math.log((this.totalDocs + 1) / (df + 1)) + 1;
  }

  search(query, { limit = 10 } = {}) {
    const queryTerms = tokenize(query);
    if (queryTerms.length === 0) return [];

    const scores = new Map();
    for (const term of queryTerms) {
      const postings = this.invertedIndex.get(term);
      if (!postings) continue;
      const idf = this._idf(term);
      for (const [docId, tf] of postings.entries()) {
        const docLen = this.docStats.get(docId)?.length || 1;
        const tfNorm = tf / docLen;
        scores.set(docId, (scores.get(docId) || 0) + tfNorm * idf);
      }
    }

    return [...scores.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([docId, score]) => ({
        id: docId,
        score: Number(score.toFixed(4)),
        ...this.docStats.get(docId).fields,
      }));
  }

  suggest(prefix, limit = 5) {
    let node = this.trieRoot;
    for (const ch of prefix.toLowerCase()) {
      if (!node.children.has(ch)) return [];
      node = node.children.get(ch);
    }
    return [...node.terms].slice(0, limit);
  }

  stats() {
    return {
      totalDocuments: this.totalDocs,
      totalTerms: this.invertedIndex.size,
    };
  }
}

module.exports = { SearchEngine, tokenize };
